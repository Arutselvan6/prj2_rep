package codes.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import codes.Model.ChatUser;

@Service
public class EmailService {

	public static final String REPLY_TO_ADDRESS = "dontreply@sitnchat.com";
	public static final String FROM_ADDRESS = "reg@sitnchat.com";
	
	@Autowired
	private JavaMailSender jms;
	
	public void send(ChatUser user, String subject, String body) throws MessagingException{
		MimeMessage mail = jms.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mail,true);
		helper.setReplyTo(REPLY_TO_ADDRESS);
		helper.setFrom(FROM_ADDRESS);
		helper.setSubject(subject);
		helper.setText(body);
		jms.send(mail); 
	}
}
