package codes.Service;

public interface BlogServiceDAO {

}
