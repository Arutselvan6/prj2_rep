package codes.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	@RequestMapping("/")
	public String goHome(){
		return "index";
	}
	
	@RequestMapping("/login")
	public String goLogin(){
		return "login";
	}
	
	@RequestMapping("/logout")
	public String goOut(){
		return "logout";
	}
	
	@RequestMapping("/aindex")
	public String goAdmin(){
		return "aindex";
	}
}
