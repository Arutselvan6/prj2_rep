package codes.Controller;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import codes.Model.ChatUser;
import codes.Service.EmailService;
import codes.Service.UserServiceDAO;

@Controller
public class UserController {

	@Autowired
	UserServiceDAO usd;
	//@Autowired
	//EmailService es;
	
	ModelAndView m;
	
	@ModelAttribute("user1")
	public ChatUser getUser(){
		return new ChatUser();
	}
	
	@RequestMapping("/register")
	public String goRegister(){
		return "register";
	}
	ChatUser u;
	@RequestMapping("/uindex")
	public ModelAndView goUser(HttpServletRequest req){
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String n = auth.getName();
		ModelAndView m = new ModelAndView("uindex");
		u = usd.getUserByName(n);
		System.out.println("Name : "+u.getUname());
		m.addObject("u1", u);
		return m;
	}
	
	@RequestMapping("/userprof")
	public ModelAndView goprofile(){
		ModelAndView m = new ModelAndView();
		System.out.println("Object is there : "+u.getEmail());
		m.setViewName("UserProfile");
		m.addObject("u1",u);
		m.addObject("imgname", u.getUserId());
		return m;
	}
	
	@RequestMapping(value="/addUser",method=RequestMethod.POST)
	public ModelAndView addU(@Valid @ModelAttribute("user1") ChatUser u, @RequestParam("cpass")String cp,HttpServletRequest req, BindingResult br ){
		if(br.hasErrors()||!cp.equals(u.getPass())){
			m = new ModelAndView("register");
			return m;
		}
		usd.addUser(u);
		MultipartFile itemImage = u.getProfilePic();
        String rootDirectory = req.getSession().getServletContext().getRealPath("/");
        File f = new File(rootDirectory + "resources\\images\\");
        if(!f.exists())
        	f.mkdirs();
        Path path = Paths.get(rootDirectory + "resources\\images\\"+u.getUserId()+".jpg");
        
        if (itemImage != null && !itemImage.isEmpty()) {
            try {
            	itemImage.transferTo(new File(path.toString()));
            	System.out.println("Image Uploaded - "+rootDirectory + "resources\\images\\"+u.getUserId()+".jpg");
            } catch (Exception e) {
                e.printStackTrace();
                throw new RuntimeException("item image saving failed.", e);
            }
        }
		/*try{
			es.send(u, "Your Sit'n Chat Account Activation", "Welcome to Sit'n Chat! You have registered Successfully. ");
		}
		catch(MessagingException me){
			System.out.println(me);
		}*/
		m = new ModelAndView("UserProfile");
		m.addObject("u1",u);
		m.addObject("imgname", u.getUserId());
		return m;
	}
}
