package codes.DAO;

public interface BlogDAO {

}
