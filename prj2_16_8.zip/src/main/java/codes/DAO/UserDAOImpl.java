  package codes.DAO;

import java.util.ArrayList;

 

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger; 
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import codes.Model.ChatUser;

@Repository

public class UserDAOImpl implements UserDAO {

	@Autowired
	SessionFactory sf;
	
	private static final Logger log = LoggerFactory.getLogger(UserDAOImpl.class);
	
	Session s;
	Transaction t;
	ChatUser x;
	ArrayList<ChatUser> l;
	
	@Override
	public void addUser(ChatUser u) {
		s = sf.openSession();
		t = s.beginTransaction();
		u.setEnabled(true);
		u.setRole("ROLE_USER");
		s.save(u);
		t.commit();
		log.info("User Added Successfully");
	}

	@Override
	public void delUser(ChatUser u) {
		s = sf.openSession();
		t = s.beginTransaction();
		s.delete(u);
		t.commit();
	}

	@Override
	public void updUser(ChatUser u) {
		s = sf.openSession();
		t = s.beginTransaction();
		s.saveOrUpdate(u);
		t.commit();
	}

	@Override
	public ChatUser getUserById(int uid) {
		s = sf.openSession();
		t = s.beginTransaction();
		x = (ChatUser)s.load(ChatUser.class, uid);
		t.commit();
		return x;
	}

	@Override
	public ChatUser getUserByName(String uname) {
		s = sf.openSession();
		t = s.beginTransaction();
		x = null;
		getAllUsers();
		for(ChatUser z: l){
			if(z.getUname().equals(uname)){
				x = z;
				break;
			}
		}
		return x;
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	@Override
	public ArrayList<ChatUser> getAllUsers() {
		s = sf.openSession();
		t = s.beginTransaction();
		l = (ArrayList<ChatUser>)s.createCriteria(ChatUser.class).list();
		return l;
	}

}
